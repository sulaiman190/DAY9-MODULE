//express is now `require`able from node_modules by name
var express = require('express');